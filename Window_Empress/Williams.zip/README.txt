Teddy Williams
November 7, 2016
CS 351 NATO Translator.
Due: November 28, 2016

Please Read Me!

User Input: In order that have the text translated either from NATO to English or English to NATO, the user must modify the words.txt file.

Please Note: This program will interpret the file to see if the file starts with a NATO word. If the file does not start with a NATO word the
will treat it as English. No specification of file is needed.

Output: It will show the user the file context
